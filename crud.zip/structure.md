CRUD (project)/
├── css/
│   └── styles.css
├── images/
│   └── (uploaded images)
├── includes/
│   ├── header.php
│   └── footer.php
├── js/
│   └── scripts.js
├── index.php
├── create.php
├── read.php
├── update.php
├── delete.php
├── login.php
└── logout.php
└── db.php

Defaut username password:
gurneet
gurneet