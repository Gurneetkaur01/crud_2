<?php
include 'db.php';

$username = 'gurneet';
$password = 'gurneet';

// Hash the password before storing it in the database
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO users (username, password) VALUES (?, ?)";
$stmt = $pdo->prepare($sql);
$stmt->execute([$username, $hashedPassword]);

echo "User created successfully!";
?>
